package com.apache.cxf.formparam.service;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

@Path("/player")
public interface IPlayerService {

	// http://localhost:8080/ApacheCXF-FormParam/services/player/addinfo
	@POST
	@Path("/addinfo")
	public Response getPlayerInfo(
			@FormParam("name") String playerName, 
			@FormParam("age") int age, 
			@FormParam("matches") int matches);
	
	// http://localhost:8080/ApacheCXF-FormParam/services/player/addPlayer/Shravan/15/35
	@POST
	@Path("/addPlayer/{name}/{age}/{matches}")
	public Response getPlayerInfoByPathParam(
			@PathParam("name") String playerName, 
			@PathParam("age") int age, 
			@PathParam("matches") int matches);
	
	// http://localhost:8080/ApacheCXF-FormParam/services/player/addPlayerByQueryParam?name=Shravan&age=15&matches=35
	@GET
	@Path("/addPlayerByQueryParam")
	public Response getPlayerInfoByQueryParam(
			@QueryParam("name") String playerName, 
			@QueryParam("age") int age, 
			@QueryParam("matches") int matches);
	
	// http://localhost:8080/ApacheCXF-FormParam/services/player/addPlayerByMatrixParam;name=Shravan;age=15;matches=355
	@GET
	@Path("/addPlayerByMatrixParam")
	public Response getPlayerInfoByMatrixParam(
			@MatrixParam("name") String playerName, 
			@MatrixParam("age") int age, 
			@MatrixParam("matches") int matches);
}