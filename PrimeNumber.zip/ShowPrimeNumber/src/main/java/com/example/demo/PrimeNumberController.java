package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.POST;
import javax.ws.rs.PathParam;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PrimeNumberController {
	
	
	
	@POST
	@RequestMapping("/primeNumber")
	public List<Integer> getPrimeNumberList(@PathParam("number") int number){
		
		List<Integer> primeNumberList = new ArrayList<>();

		for (int i = 2; i < number; i++) {
			boolean isPrimeNumber = true;
			for (int j = 2; j < i; j++) {
				if (i%j  == 0) {
					isPrimeNumber = false;
				}
			}
			
			if (isPrimeNumber) {
				primeNumberList.add(i);
			}
			
		}
		
		return primeNumberList;
	}
		
}
